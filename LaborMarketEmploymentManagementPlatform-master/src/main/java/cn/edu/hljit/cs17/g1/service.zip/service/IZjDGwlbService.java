package cn.edu.hljit.cs17.g1.service;

import cn.edu.hljit.cs17.g1.pojo.CdgDeformity;
import cn.edu.hljit.cs17.g1.pojo.ZjDGwlb;

import java.util.List;

public interface IZjDGwlbService {
    public List<ZjDGwlb> getAll();
}
