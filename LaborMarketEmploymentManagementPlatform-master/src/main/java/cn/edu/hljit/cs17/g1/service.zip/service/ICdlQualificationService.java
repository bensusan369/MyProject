package cn.edu.hljit.cs17.g1.service;

import cn.edu.hljit.cs17.g1.pojo.CdlQualification;

import java.util.List;

public interface ICdlQualificationService {
    public List<CdlQualification> getAll();

}
