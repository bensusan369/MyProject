package cn.edu.hljit.cs17.g1.service;

import cn.edu.hljit.cs17.g1.pojo.CdgDeformity;
import cn.edu.hljit.cs17.g1.pojo.CdlPersonneltype;

import java.util.List;

public interface ICdlPersonneltypeService {
    public List<CdlPersonneltype> getAll();
}
