package cn.edu.hljit.cs17.g1.service;

import cn.edu.hljit.cs17.g1.pojo.CdgDeformity;
import cn.edu.hljit.cs17.g1.pojo.CdlRprtype;

import java.util.List;

public interface ICdlRprtypeService {
    public List<CdlRprtype> getAll();
}
