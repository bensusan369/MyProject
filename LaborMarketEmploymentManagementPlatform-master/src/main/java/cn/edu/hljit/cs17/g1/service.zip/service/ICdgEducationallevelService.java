package cn.edu.hljit.cs17.g1.service;

import cn.edu.hljit.cs17.g1.pojo.CdgDeformity;
import cn.edu.hljit.cs17.g1.pojo.CdgEducationallevel;

import java.util.List;

public interface ICdgEducationallevelService {
    public List<CdgEducationallevel> getAll();
}
