package cn.edu.hljit.cs17.g1.service;

import cn.edu.hljit.cs17.g1.pojo.CdgMarriage;
import cn.edu.hljit.cs17.g1.pojo.CdgNation;

import java.util.List;

public interface ICdgNationService {
    public List<CdgNation> getAll();
}
