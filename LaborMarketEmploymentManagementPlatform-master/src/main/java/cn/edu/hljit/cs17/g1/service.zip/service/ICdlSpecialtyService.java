package cn.edu.hljit.cs17.g1.service;

import cn.edu.hljit.cs17.g1.pojo.CdlQualification;
import cn.edu.hljit.cs17.g1.pojo.CdlSpecialty;

import java.util.List;

public interface ICdlSpecialtyService {
    public List<CdlSpecialty> getAll();
}
